﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace processpayloaddata
{
    class Product_Detail
    {
        public string Code__c { get; set; }
    }

    class ProductLine__c : Product_Detail { }
    class ProductClass__c : Product_Detail { }
    class ProductType__c : Product_Detail { }



}
