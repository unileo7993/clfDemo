﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace processpayloaddata
{
    class Product_Detail
    {
        public string Code__c { get; set; }
        public Product_Detail(string Code__c)
        {
            this.Code__c = Code__c;
        }
    }

    class ProductLine__c : Product_Detail {
        public ProductLine__c(string Code__c) : base(Code__c)
        {

        }
    }
    class ProductClass__c : Product_Detail
    {
        public ProductClass__c(string Code__c) : base(Code__c)
        {

        }
    }
    class ProductType__c : Product_Detail
    {
        public ProductType__c(string Code__c) : base(Code__c)
        {

        }
    }



}
