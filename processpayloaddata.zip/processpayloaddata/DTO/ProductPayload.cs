﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace processpayloaddata
{
    class ProductPayload
    {
        public dynamic SBQQ__PriceEditable__c { get; set; }
        public dynamic SBQQ__DescriptionLocked__c { get; set; }
        public string Name { get; set; }
        public bool IsActive { get; set; }
        public string ProductCode { get; set; }
        public string Description { get; set; }
        public string SalesText__c { get; set; }
        public string QuoteText__c { get; set; }
        public string CountryOrigin__c { get; set; }
        public string Set__c { get; set; }

        public ProductLine__c  ProductLine__c { get; set; }
        public ProductClass__c ProductClass__c { get; set; }
        public ProductType__c ProductType__c { get; set; }

        public string Product_Image_Link__c { get; set; }


    }
}
