﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace processpayloaddata
{
    class Utilities
    {
        public static ProductPayload ProcessProductPayloadJson(string productJson)
        {
            JObject o = JObject.Parse(productJson);
            
            ProductPayload productPayload = new ProductPayload();
            productPayload.SBQQ__PriceEditable__c = ((string)o.SelectToken("$.family") == "artificial_crm_model"); // values such as 'artificial_crm_model' must be declared in global constants;
            productPayload.SBQQ__DescriptionLocked__c = !((string)o.SelectToken("$.family") == "artificial_crm_model");// values such as 'artificial_crm_model' must be declared in global constants;
            productPayload.Name = (string)o.SelectToken("$.values.product_name[0].data");
            productPayload.IsActive = (bool)o.SelectToken("$.enabled");
            productPayload.ProductCode = (string)o.SelectToken("$.values.item_number_sales[0].data");
            productPayload.Description = (string)o.SelectToken("$.values.item_description[?(@.locale=='en_US')].data");// values such as 'en_US' must be declared in global constants;
            productPayload.SalesText__c = (string)o.SelectToken("$.values.sales_text[?(@.locale=='en_US')].data");
            productPayload.QuoteText__c = (string)o.SelectToken("$.values.quote_text[?(@.locale=='en_US')].data");
            productPayload.CountryOrigin__c = (string)o.SelectToken("$.values.country_origin[0].data");
            productPayload.Set__c = (string)o.SelectToken("$.values.set[0].data");
            productPayload.Product_Image_Link__c = (string)o.SelectToken("$.values.model_picture_main_out[0].data");
            productPayload.ProductLine__c = new ProductLine__c((string)o.SelectToken("$.values.product_line[0].data"));
            productPayload.ProductClass__c = new ProductClass__c((string)o.SelectToken("$.values.product_class[0].data"));
            productPayload.ProductType__c = new ProductType__c((string)o.SelectToken("$.values.product_type[0].data"));

            return productPayload;

        }


    }
}
